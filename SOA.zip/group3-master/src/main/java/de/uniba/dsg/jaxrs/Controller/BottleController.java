package de.uniba.dsg.jaxrs.Controller;

public class BottleController {
}
