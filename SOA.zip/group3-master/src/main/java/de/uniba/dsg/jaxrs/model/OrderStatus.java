package de.uniba.dsg.jaxrs.model;

public enum OrderStatus {
    SUBMITTED, PROCESSED
}
