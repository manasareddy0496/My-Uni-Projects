package de.uniba.dsg.jaxrs.model;

public interface Beverage {
}
